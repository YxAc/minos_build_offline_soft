.. MySQLdb documentation master file, created by
   sphinx-quickstart on Sun Oct 07 19:36:17 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MySQLdb's documentation!
===================================

Contents:

.. toctree::
    :maxdepth: 3

    user_guide
    MySQLdb
    FAQ

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

