_mysql_exceptions Module
========================

.. automodule:: _mysql_exceptions
    :members:
    :undoc-members:
    :show-inheritance:
